Create Database SQLTraining

CREATE DATABASE financial_transactions_db;

USE financial_transactions_db;

CREATE TABLE financial_transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT,
    supplier_name VARCHAR(50),
    transaction_date DATE,
    amount DECIMAL(10, 2),
    currency VARCHAR(10)
);

INSERT INTO financial_transactions (transaction_id, customer_id, supplier_name, transaction_date, amount, currency)
VALUES
    (1, 101, 'ABC Corp', '2024-01-15', 1000.00, 'USD'),
    (2, 102, 'XYZ Ltd', '2024-01-20', 1500.50, 'EUR'),
    (3, 103, 'Global Inc', '2024-02-05', 2000.00, 'GBP'),
    (4, 104, 'ABC Corp', '2024-02-10', 500.25, 'USD');

	Select * from financial_transactions

CREATE TABLE customer_details (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20)
);

INSERT INTO customer_details (customer_id, customer_name, email, phone)
VALUES
    (101, 'John Doe', 'john.doe@example.com', '123-456-7890'),
    (102, 'Jane Smith', 'jane.smith@example.com', '234-567-8901'),
    (103, 'Mike Johnson', 'mike.johnson@example.com', '345-678-9012'),
    (104, 'Emily Davis', 'emily.davis@example.com', '456-789-0123');

Select * from customer_details

CREATE DATABASE financial_data_warehouse;

CREATE TABLE financial_analysis (
    transaction_id INT PRIMARY KEY,
    customer_name VARCHAR(50),
    supplier_name VARCHAR(50),
    transaction_date DATE,
    amount_usd DECIMAL(10, 2),
    supplier_phone VARCHAR(20)
);

Select * from [dbo].[financial_transactions]

Select * from [dbo].[financial_transactions]
----------------
Select * from [dbo].[financial_transactions]
Select * from [dbo].[customer_details]

Select t.*, c.customer_name, c.email customer_email, c.phone customer_phone 
from financial_transactions t inner join customer_details c on t.customer_id=c.customer_id
------------------------

Select * from [dbo].[financial_transactions]

alter table [dbo].[financial_transactions]
add [customer_name] [varchar](50) NULL,
	[customer_email] [varchar](100) NULL,
	[customer_phone] [varchar](20) NULL

	Truncate table [dbo].[financial_transactions]

---------------
CREATE TABLE exchange_rates(
from_currency varchar(10),	
to_currency	varchar(10),
exchange_rate float,	
effective_date date
)

CREATE TABLE suppliers
(
supplier_id	int,
supplier_name Varchar(100),	
contact_name varchar(100),	
phone varchar(25)
)


Select * from[dbo].[financial_transactions] 
Select * from [dbo].[exchange_rates]
Select * from [dbo].[suppliers]

Select * from [dbo].[financial_transactions]

alter table [dbo].[financial_transactions]
add amount_USD float
----------------------
alter table [dbo].[financial_transactions]
add [supplier_contact_name] [varchar](100) NULL,
	[supplier_phone] [varchar](25) NULL

	
ALTER TABLE [dbo].[financial_transactions]
DROP COLUMN supplier_contact_name 
ALTER TABLE [dbo].[financial_transactions]
DROP COLUMN supplier_phone 


UPDATE [dbo].[financial_transactions]
SET supplier_name = 'ABC Corp'
WHERE customer_id = 104;

--aFTER DEPLOYEMENT YOU CAN EXPAND SSIDB THEN, In that project under Environment crate one environement that is called "Dev".
--After creation Environment under environment properties is there then in that property click variables and add the variables(go to project click on right and click configure option is there and in side parameters are there and add the same parameters on that variables).
--under project right click and select the configure and there is "..." select this one then there and select the Use environment variable option is there whatever it is select.
--after you can create a NEW SQL Server agent job inside So many options is there like : General,Steps,Shedule,Alerts,Notifications,Tagets.In side new job page there another New Option is there Create New job and then you can start the job then you can find the result.
--Right click on Service job and click on the Reports-> Standard Reports


