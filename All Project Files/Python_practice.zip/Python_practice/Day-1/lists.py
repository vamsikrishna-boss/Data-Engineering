# Remove:

# l=[1,2,3,4,5,6,7,8,9]
# l.remove(8)
# print(l)


# pop:

fruits=[1,2,3,4,5]
removed_fruits=fruits.pop(4)
print("removed_fruits:"removed_fruits)

