##Input_Output comments in python:

#name = input("Enter yourname")
#age = int(input("Enter your age:"))
#print("Hello,"+name+"!you are",age,"ye old")



## Finding Data TYPE:

a = "Hello World"
b = 10
c = 11.22
d = ("Geeks", "for", "Geeks")
e = ["Geeks", "for", "Geeks"]
f = {"Geeks": 1, "for": 2, "Geeks": 3}

print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
print(type(f))

## 
name = input("Enter your name: ")
print("Hello,", name, "! Welcome!")

# Taking three inputs
x, y, z = input("Enter three values: ").split()
print("Total number of students:", x)
print("Number of boys is:", y)
print("Number of girls is:", z)


