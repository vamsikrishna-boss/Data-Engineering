s = input()
s2 = s.lower()
a = s2.count('a')
e = s2.count('e')
i = s2.count('i')
o = s2.count('o')
u = s2.count('u')

print(f"Number of vowels:{a+e+i+o+u}")

