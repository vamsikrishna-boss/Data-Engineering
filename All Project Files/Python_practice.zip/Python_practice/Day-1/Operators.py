#-------------------------------------------------------- Arthematic Operators -------------------------------------------------------

# Addition:

a = 10
b = 20
c = a+b
print("Addition is:", c)

# Subtraction

a = 20
b = 10
c = a-b
print("Subtraction is:", c)

# Multiplication

a = 10
b = 20
c = a*b
print("Multiplication is:", c)

# Division

a = 10
b = 20
c = a/b
print("Addition is:", c)

# Floor devision

a = 10
b = 3
c = a//b
print("Floor devision of :", c)

# Modulo

a = 10
b = 3
c = a%b
print("Modulo of :", c)

# Exponential : 1^2=1

a = 10
b = 3
c = a**b
print("Exponential of :", c)


#-------------------------------------------------------- Assignement Operators -------------------------------------------------------
# Assignement operators

X = 10
print("X value of:", X)

# Add of Addition: +=

X = 10
Y = 20
X += 20
Z = X + Y
print("Adds of Addition is:", Z)

# Add of Subtraction: -=

X = 10
Y = 20
X -= 20
Z = X + Y
print("Adds of Subtraction is:", Z)

# Add of Multiplication: *=

X = 10
Y = 20
X *= 20
Z = X * Y
print("Adds of Multiplication is:", Z)

# Add of Devide and Assign: /=

X = 10
Y = 20
X /= 20
Z = X / Y
print("Adds of Devide and Assign is:", Z)

# Add of Floor Devide and Assign: //=

X = 10
Y = 20
X //= 20
Z = X // Y
print("Adds of floor devision of Assign is:", Z)

# Add of Floor Modulo and Assign: %=

X = 10
Y = 20
X %= 20
Z = X % Y
print("Adds of floor devision of Assign is:", Z)

# Add of Exponential and Assign: **=

X = 10
Y = 20
X **= 20
Z = X ** Y
print("Adds of Exponential of Assign is:", Z)


#--------------------------------------------------------Comparision Operators -------------------------------------------------------

# Equal to operator: == 

X = 10
Y = 10
Z = X == Y
print(Z)


# Not Equal to operator: !=

X = 10
Y = 20
Z = X != Y
print(Z)

# Greater then operator: >

X = 10
Y = 20
Z = X>Y
print(Z)

# Less then operator: <

X = 10
Y = 20
Z = X<Y
print(Z)

# Greater then Equal to: >=

X = 10
Y = 20
Z = X >= Y
print(Z)

# Less then operator: <

X = 10
Y = 20
Z = X <= Y
print(Z)

#---------------------------------------------------------Logical operators ---------------------------------------------------------
#Logical operators : AND

X = True
Y = False
Z = X and Y
print(Z)

#Logical operators : or

X = True
Y = False
Z = X or Y
print(Z)

#Logical operators : or

X = True
Z = not X
print(Z)

#----------------------------------------------------------Membership operators--------------------------------------------------------
# In Membership Operator:

fruits = ['apple', 'Orenge', 'Banana', 'Mango']
is_apple_in_list = 'Mango' in fruits
print("'apple' is in the list of fruits:",is_apple_in_list)

# is not membership operator:

fruits = ['apple', 'Orenge', 'Banana', 'Mango']
is_not_apple_in_list = 'lemmon' in fruits
print("'lemon is not in the list of fruits:", is_not_apple_in_list)

#----------------------------------------------------------- Bitwise Operators ---------------------------------------------------------

# Bitwise And (&): 

a = 2
b = 3
print(a & b)

# Bitwise OR (|): 

a = 2
b = 3
print(a | b)

# Bitwise XOR(^): 

a = 2
b = 3
print(a^b)

#Bitwise Left Shift(<<): 

a = 2
b = 2
print(a<<b)

#Bitwise Left Shift(<<): 

a = 32
b = 2
print(a>>b)

#Input and Output

# name = input("Enter your name:")
# age = int(input("Enter your age:"))
# print("Hello, " + name + "!you are Age is",age,"years old.")


#Error Handling

# a = int(input("given value is: "))
# print(a)

# OUTPUT

# a = int(input("Give a value: "))
# b = int(input("give b value: "))

# #print(a,b)
# # print(a,b,sep=" Hello world ")
# print(a,b,sep=" - ")



# Ex:1 String input and output

# name = input("enter name: ")
# print("Hello",name,sep=",")

# Ex:2 Integer input and Output

# num = 5
# print("You entered:",num,sep="")

# Ex: 3 Float input and Output
 
# fl = float(input("Give to float: "))
# print("value of Pi:",fl)


# Ex:4 taking multiple inputs in a single line

# a = input( )
# x,y,z = a.split(" ")
# sum = int(x) + int(y) + int(z)
# print("Sum of inputs:",sum)


# Ex:5 Specifying separator from output

# inp = input("Enter name and age: ")
# name,age = inp.split(",")
# print("Name:",name,",Age:",age,sep="")


# Ex:6 End parameters in output

# n = int(input("Enter the value: "))
# print("Countdown: 5 4 3 2 1" , end =" Blast off!")

#Ex:7 Arthematic Operator

# x,y = input("Enter a and b values: ").split(",")
# a = int(x)
# b = int(y)
# print("Addition:",a+b,",Subtraction:",a-b,",Multiplication:",a*b,",Division:",a/b,sep= "")

#Ex:8 Comparision operator

# x,y = input("Enter a and b values: ").split(",")
# a = int(x)
# b = int(y)
# print("10>5:",a>5,",10<5:",10<5,",10 == 5:",10 == 5,",10!=5:",10!=5,sep= "")

# Ex: 9 Logical  Operator:

# x,y = input("Enter a and b values: ").split(",")
# a = bool(x)
# b = bool(y)
# print("True and false:",True and False,",True or False:",True or False,",not True:",not True,sep= "")

#Ex: 10 : Taking Yes/No Input and Handling Case Sensitive

# s = str(input("Enter the bool: "))
# print("You entered:", s)

# Ex:11 Formatting output using f-strings

x,y = input("Enter name and age:").split(",")
print(f"Name:{x},Age:{y} years")

