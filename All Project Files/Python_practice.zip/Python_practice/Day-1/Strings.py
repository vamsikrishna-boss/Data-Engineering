#Ex:1

#str = "PYTHON"
#print(str[0])
#print(str[2])
#print(str[-1])

#Ex:2

## String Slicing

Name = "MICHAELJACKSON"
print(Name[0])
print(Name[0:4])
print(Name[0:4:2])

#Ex:3

s = "Hello World"

print(s[1])
print(s[-1])
print(s[1:3])
print(s[1:-1])
print(s[3])
print(s[2:])
print(s[:-1])
print(s[::2])
print(s[1::2])
print(s[::-1])

## Ex:4

##String Concatination:

first_name = "John"
Last_name = "Doe"
full_name = first_name+" "+Last_name
print(full_name)

## Ex:5

## String Length

#Ex:1
String1 = "Coading is fun"
print(len(String1))

#Ex:2
String2 = "Hello, World"
print(len(String2))

#Ex:3
String3 = "abcdefghijk"
print(len(String3))

#Ex:4
String4 = "The quick brown for jumps over the lazy dog"
print(len(String4))