##Question : 1

# Sample input : num1 = 5
#                num2 = 10

# Sample output : Sum = 15

num1 = int(input())
num2 = int(input())

print("Sum:",num1+num2,sep="")

##Question : 2

## Finding the area of the circle

radius = int(input("give an range: "))
a = 3.14*(radius*radius)

print("Area of the circle:",a)
print("Area of the circle:",a,sep="")
print(f"Area of the circle:{a}")

##Question : 3

## Solving Quadratic equations

a = int(input("Give a: "))
b = int(input("Give b: "))
c = int(input("Give c: "))

root1 = 0
root2 = 0
d = (b**2) - 4*a*c
root1 = (-b + (d**(0.5)))/2*a
##root2 = (-b - (d**(0.5)))/2*a

print(f"roots:({root1},{root2})")


## Swap the two variables without using temp tables

a = int(input("Give a: "))
b = int(input("Give b: "))

temp = b
b = a
a = temp

print(f"value of a is: {a}")
print(f"value of b is: {b}")


## Conerting temparature units

def convert_temperature(celsius):
    # Convert Celsius to Fahrenheit
    fahrenheit = celsius * 9/5 + 32
    # Convert Celsius to Kelvin
    kelvin = celsius + 273.15
    return fahrenheit, kelvin

# Sample input
celsius = 30
fahrenheit, kelvin = convert_temperature(celsius)

# Sample output
print(f"Temperature in Fahrenheit = {fahrenheit:.1f}")
print(f"Temperature in Kelvin = {kelvin:.2f}")


## Basic currency converter

def convert_currency(amount_in_usd, exchange_rate_usd_to_eur):
    # Convert USD to EUR
    amount_in_eur = amount_in_usd * exchange_rate_usd_to_eur
    return amount_in_eur

# Sample input
amount_in_usd = 100
exchange_rate_usd_to_eur = 0.85

# Conversion
amount_in_eur = convert_currency(amount_in_usd, exchange_rate_usd_to_eur)

# Sample output
print(f"Equivalent amount in EUR = {amount_in_eur:.1f}")