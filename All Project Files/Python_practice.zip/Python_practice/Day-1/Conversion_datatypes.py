# print("This is my first program Hello world")

# Implecit Type conversion

a = 100
b = 1.5
c = a+b
print(c)
print(type(c)) 

# Explicit type conversion

a = 100
a = float(a)
print(type(a))
print(a)

a = 100
print(type(a))

# Conversion Float to Numeric

a = 10.5
a = int(a)
print(type(a))
print(a)

# Ex:1

num = 5 + 2.0
print(type(a))
print(a)

# Ex:1 conversion float to int

num = 5 + 2.0
num = int(num)
print(type(num))
print(num)


#Ex:2
num = 5
print(type(num))
print(num)

#Ex:2 Conversion int to float
num = 5
num = float(num)
print(type(num))
print(num)

#Ex:3 
message = 42
print(type(message))
print(message)

# Ex:3 Conversion of int to Str
message = 42
message = str(message)
print(type(message))
print(message)


# Ex:4
num1 = 1
num2 = 0
print(type(num1))
print(type(num2))
print(num1)
print(num2)

# Ex:4 Conversion num to boolean
num1 = 1
num2 = 0
num1 = bool(num1)
num2 = bool(num2)
print(type(num1))
print(type(num2))
print(num1)
print(num2)



# ASCII Values
#Ex:1 find out the value of A
# use ord() & char()

str = 'A'
Str_A = ord(str)
print("ASCII value of 'A' is:", Str_A)

#Ex:2 Find out the char of 65

num = 65
num_n = chr(num)
print("ASCII vaue of 65 is:", num_n)