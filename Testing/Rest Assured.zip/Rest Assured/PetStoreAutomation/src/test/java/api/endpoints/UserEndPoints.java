package api.endpoints;

import static io.restassured.RestAssured.given;

import api.payload.User;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

//UserEndPoints.java
//Created for perform Create, Read, Update, Delete

public class UserEndPoints {
	
	public static Response createUser(User payload)// This particular method call from test case by passing payload
	{
		Response response=given()
		 .contentType(ContentType.JSON)
		 .accept(ContentType.JSON)
		 .body(payload)
		.when()
		 .post(Routes.post_url);
		
		return response; // once we return the response capture the response then we do validation.
		
	}
	
	public static Response readUser(String userName)
	{
		Response response=given()
				.pathParam("username",userName)
		.when()
		      .get(Routes.get_url);
		
		return response;
	}
	
	public static Response updateUser(String username, User payload)
	{
		Response response=given()
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				.body(payload)
			.when()
			    .put(Routes.update_url);
		
		 return response;
	}
	
	public static Response deleteUser(String userName)
	{
		Response response=given()
				.pathParam("username",userName)
			.when()
			    .delete(Routes.delete_url);
		
		    return response;
	}
		
	}
