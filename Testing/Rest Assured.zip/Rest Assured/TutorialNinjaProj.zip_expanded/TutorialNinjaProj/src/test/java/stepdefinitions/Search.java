package stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import factory.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Search {
	
	WebDriver driver;

	@Given("User opens the application")
	public void User_opens_the_application() {
		
		driver = DriverFactory.getDriver();
	}
	
	@When("User enters valid product {string} into Search box field")
	public void user_enters_valid_product_into_Search_box_field(String validProductText) {
		
		driver.findElement(By.name("Search")).sendKeys(validProductText);
}

	
	@When("User clicks on search button")
	public void User_clicks_on_search_button() {
		
		driver.findElement(By.xpath("//button[contains(@class,'btn-default')]")).click();
		
	}
	
	@Then("User should get valid product displayed in search results")
	public void User_should_get_valid_product_displayed_in_search_results() {
		
		Assert.assertTrue(driver.findElement(By.linkText("Hp LP3065")).isDisplayed());
	}
	
	@When("User enters invalid product {string} into Search box field")
    public void user_enters_invalid_product_into_Search_box_field(String invalidProductText) {
		
		driver.findElement(By.xpath("search")).sendKeys(invalidProductText);
	}
	
	@Then("User should get a message about no product matching")
	public void User_should_get_a_message_about_no_product_matching() {
	
		Assert.assertEquals("There is no product that matches the search creteria.",driver.findElement(By.xpath("//input[@id='button-search']/following-sibling::p")).getText());	
	}
	
	@When("User dont enter any product name into search box field")
	public void user_dont_enter_any_product_name_into_Search_box_field() {
		
		//Intentionally kept blank
	}
}