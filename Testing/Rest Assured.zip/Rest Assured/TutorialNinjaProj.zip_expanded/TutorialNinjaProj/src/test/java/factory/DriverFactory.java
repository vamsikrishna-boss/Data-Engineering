package factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

public class DriverFactory {
	
	static WebDriver driver = null;
	
	public static WebDriver initializeBrowser(String browserName) {
		
		if(browserName.equals("chrome")) {
		
//			System.setProperty("webdriver.chrome.driver", "C:\\Users\\saikr\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
//			ChromeOptions chromeOptions = new ChromeOptions();
//			chromeOptions.addArguments("--remote-allow-origins=*");
//			 driver = new ChromeDriver(chromeOptions);
			driver = new ChromeDriver();
				
			}else if(browserName.equals("firefox")) {
				
			 driver = new FirefoxDriver();
				
			}else if(browserName.equals("Edge")) {
				   
			 driver = new EdgeDriver();
					
			}else if(browserName.equals("Safari")) {
					
		     driver = new SafariDriver();
			
			}
		return driver;
	}
		public static WebDriver getDriver() {
			 return driver;
			}
}