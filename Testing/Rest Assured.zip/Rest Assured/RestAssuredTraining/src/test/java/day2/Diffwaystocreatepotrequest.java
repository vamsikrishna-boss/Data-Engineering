package day2;


import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;

import org.testng.annotations.Test;

public class Diffwaystocreatepotrequest {
	
	@Test(priority=1)
	void PostHashmap()
	{
		HashMap data = new HashMap();
		
		data.put("name","mani");
		//String jobArr[]= {"Hardware"};
		data.put("job","Hardware");
		
		given()
		.contentType("application/json")
		.body(data)
		
		.when()
		.post("https://reqres.in/api/users")
		
		.then()
		 .statusCode(201)
//		 .body("name",equalTo("mani"))
//		 .body("job",equalTo("Hardware"))
//		 .headers("content-Type","application/json","charset=utf-8")
		 .log().all();
	}
	}
