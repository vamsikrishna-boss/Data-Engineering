package day3;

import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.Map;

public class CookiesDemo {
	
	@Test
	void testCookies() //handle the cookies
	{
		given()
		
		.when()
		   .get("https://www.google.com")
		   
		.then()
		   .cookies("AEC","AQTF6HwTffwXLRb_NP1BGEyDWR8GJ82iLkyoKd6r19A4REId38MNUv8SjbM")
		   .log().all();
	}

	 @Test(priority=2)
	 void getCookiesInfo()
	 {
		 Response res = given()
				 
		.when()
		.get("https://www.google.com/");
		 
		 String cookie_value=res.getCookie("AEC");
		 System.out.println("value of cookie is====>"+cookie_value);
	 }
	
	 @Test(priority=2)
	 void getCookie()
	 {
		 Response res = given()
				 
		.when()
		.get("https://www.google.com/");
		 
		 Map<String,String> cookies_values=res.getCookies();
		 
		 for(String k:cookies_values.keySet())
		 {
			 String cookies_value=res.getCookie(k);
					 String cookie_value;
					System.out.println(k+"     "+cookies_value);
		 }
	 }
}
