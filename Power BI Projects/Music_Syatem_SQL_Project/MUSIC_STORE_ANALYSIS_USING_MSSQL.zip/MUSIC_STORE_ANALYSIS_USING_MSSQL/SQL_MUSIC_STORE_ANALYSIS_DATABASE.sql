/*	Question Set 1 - Easy */

/* Q1: Who is the senior most employee based on job title? */

Select TOP 1 first_name,last_name,tittle,levels
From employee
ORDER BY levels DESC

/* Q2: Which countries have the most Invoices? */
Select * from invoice

Select Count(invoice_id) 
Invoices, billing_country
FROM invoice
GROUP BY billing_country
ORDER BY Count(invoice_id) DESC;

Select * from Invoice Where billing_city = 'Prague'

/* Q3: What are top 3 values of total invoice? */

SELECT Top 3*  
FROM invoice
ORDER BY total DESC

/* Q4: Which city has the best customers? 
We would like to throw a promotional Music Festival in the city we made the most money. 
Write a query that returns one city that has the highest sum of invoice totals. 
Return both the city name & sum of all invoice totals */
Select * from Cust

SELECT TOP 1 City, SUM(support_rep_id) AS TotalRevenue
FROM Cust
GROUP BY City
ORDER BY TotalRevenue DESC;

SELECT TOP 1 C.City, SUM(I.total) AS Madecity
FROM Cust C
JOIN Invoice I ON C.Customer_id = I.Customer_id
GROUP BY C.City
ORDER BY Madecity DESC;

SELECT Top 1 billing_City, Round(SUM(total),2) AS TotalInvoiceAmount
FROM Invoice
GROUP BY billing_City
ORDER BY TotalInvoiceAmount DESC;

/*Who is the best customer? 
The customer who has spent the most money will be declared the best customer. 
Write a query that returns the person who has spent the most money */

SELECT Top 1 C.customer_id, first_name, last_name, SUM(total) AS Invoice_Total
FROM Cust C
JOIN Invoice i
ON C.customer_id = i.customer_id
GROUP BY C.Customer_id,first_name,last_name
ORDER BY Invoice_total DESC;


/* Question Set 2 - Moderate */

/* Q1: Write query to return the email, first name, last name, & Genre of all Rock Music listeners. 
Return your list ordered alphabetically by email starting with A. */

/*Method 1 */

Select * from Cust
Select * from Genre

Select DISTINCT email As Email, first_name As fname, last_name As lname, G.name As Name
from Cust As C
Join invoice As I ON C.customer_id = I.customer_id
Join invoice_line As I_L ON I.invoice_id = I_L.invoice_id
Join track As T ON I_L.track_id = T.track_id
Join Genre As G ON T.genre_id = G.Genre_id
Where G.name Like 'Rock'
ORDER BY email

/* Q2: Let's invite the artists who have written the most rock music in our dataset. 
Write a query that returns the Artist name and total track count of the top 10 rock bands. */

Select Top 10 artist.name Artists_name, Count(track.track_id) As Total_tracks
from artist
Join album ON album.artist_id = artist.artist_id
Join track ON track.album_id = album.album_id
Join Genre ON Genre.Genre_id = track.genre_id
where Genre.Name like 'Rock'
GROUP BY artist.name
ORDER BY Total_tracks DESC

SELECT TOP 35
    artist.name AS Artists_name, 
    COUNT(track.track_id) AS Total_tracks
FROM artist
JOIN album ON album.artist_id = artist.artist_id
JOIN track ON track.album_id = album.album_id
JOIN genre ON genre.genre_id = track.genre_id
WHERE genre.name LIKE 'Rock'
GROUP BY artist.name
ORDER BY Total_tracks DESC;

//*SELECT Top 8 artist.name,COUNT(artist.artist_id) AS number_of_songs
FROM track
JOIN album ON album.album_id = track.album_id
JOIN artist ON artist.artist_id = album.artist_id
JOIN genre ON genre.genre_id = track.genre_id
WHERE genre.name LIKE 'Rock'
GROUP BY artist.name
ORDER BY number_of_songs DESC *//

/* Q3: Return all the track names that have a song length longer than the average song length. 
Return the Name and Milliseconds for each track. Order by the song length with the longest songs 
listed first. */

SELECT name,milliseconds FROM track
WHERE milliseconds > (SELECT AVG(milliseconds) AS avg_track_length FROM track )
ORDER BY milliseconds DESC;

/* Question Set 3 - Advance */

/* Q1: Find how much amount spent by each customer on artists? Write a query to return customer name, artist name and total spent */

/* 
--> Steps to Solve: First, find which artist has earned the most according to the InvoiceLines.
   Now use this artist to find 
--> which customer spent the most on this artist. For this query,
       you will need to use the Invoice, InvoiceLine, Track, Customer,Album, and Artist tables.
--> Note, this one is tricky because the Total spent in the Invoice table might not be on a single product, 
so you need to use the InvoiceLine table to find out how many of each product was purchased, and then multiply
this by the price for each artist. */

/*WITH best_selling_artist AS (
   SELECT artist.artist_id AS artist_id, SUM(il.unit_price*il.quantity) AS total_sales
FROM invoice_line As il
JOIN track ON track.track_id = il.track_id
JOIN album ON album.album_id = track.album_id
JOIN artist ON artist.artist_id = album.artist_id
GROUP BY artist.artist_id
)
SELECT c.customer_id, c.first_name, c.last_name, bsa.artist_id, 
       SUM(il.unit_price * il.quantity) AS amount_spent
FROM invoice i
JOIN Cust As C ON C.customer_id = i.customer_id
JOIN invoice_line il ON il.invoice_id = i.invoice_id
JOIN track t ON t.track_id = il.track_id
JOIN album alb ON alb.album_id = t.album_id
JOIN best_selling_artist bsa ON bsa.artist_id = alb.artist_id
GROUP BY c.customer_id, c.first_name, c.last_name, bsa.artist_id
ORDER BY amount_spent DESC*/


WITH best_selling_artist AS (
   SELECT Top 10 artist.artist_id AS artist_id, artist.name AS artist_name,
          SUM(CAST(il.unit_price AS DECIMAL(10, 2)) * CAST(il.quantity AS INT)) AS total_sales
   FROM invoice_line AS il
   JOIN track ON track.track_id = il.track_id
   JOIN album ON album.album_id = track.album_id
   JOIN artist ON artist.artist_id = album.artist_id
   GROUP BY artist.artist_id, artist.name
   ORDER BY total_sales DESC
)
SELECT c.customer_id, c.first_name, c.last_name, bsa.artist_name,
       SUM(CAST(il.unit_price AS DECIMAL(10, 2)) * CAST(il.quantity AS INT)) AS amount_spent
FROM invoice i
JOIN Cust AS c ON c.customer_id = i.customer_id
JOIN invoice_line il ON il.invoice_id = i.invoice_id
JOIN track t ON t.track_id = il.track_id
JOIN album alb ON alb.album_id = t.album_id
JOIN best_selling_artist bsa ON bsa.artist_id = alb.artist_id
GROUP BY c.customer_id, c.first_name, c.last_name, bsa.artist_name 
ORDER BY amount_spent DESC

/* Q2: We want to find out the most popular music Genre for each country. We determine the most popular genre as the genre 
with the highest amount of purchases. Write a query that returns each country along with the top Genre. For countries where 
the maximum number of purchases is shared return all Genres. */

/* Steps to Solve:  There are two parts in question- first most popular music genre and second need data at country level. */

/* Method 1: Using CTE */

WITH popular_genre 
AS 
(
    SELECT 
     Cust.country, genre.name AS genre_name, genre.genre_id, COUNT(invoice_line.quantity) AS purchases, 
     ROW_NUMBER() OVER(PARTITION BY cust.country ORDER BY COUNT(invoice_line.quantity) DESC) AS RowNo 
    FROM invoice_line 
    JOIN invoice ON invoice.invoice_id = invoice_line.invoice_id
    JOIN cust ON cust.customer_id = invoice.customer_id
    JOIN track ON track.track_id = invoice_line.track_id
    JOIN genre ON genre.genre_id = track.genre_id
    GROUP BY cust.country, genre.name, genre.genre_id
)
SELECT * FROM popular_genre WHERE RowNo = 1
ORDER BY country ASC, purchases DESC

/* Method 2: With Recursive */

WITH sales_per_country AS (
    SELECT 
        COUNT(*) AS purchases_per_genre,cust.country, 
        genre.name AS genre_name, 
        genre.genre_id
    FROM invoice_line
    JOIN invoice ON invoice.invoice_id = invoice_line.invoice_id
    JOIN cust ON cust.customer_id = invoice.customer_id
    JOIN track ON track.track_id = invoice_line.track_id
    JOIN genre ON genre.genre_id = track.genre_id
    GROUP BY cust.country, genre.name, genre.genre_id
),
max_genre_per_country AS (
    SELECT 
        MAX(purchases_per_genre) AS max_genre_number, 
        country
    FROM sales_per_country
    GROUP BY country
)
SELECT spc.* 
FROM sales_per_country spc
JOIN max_genre_per_country mgpc 
    ON spc.country = mgpc.country AND spc.purchases_per_genre = mgpc.max_genre_number
ORDER BY spc.country;

/* Q3: Write a query that determines the customer that has spent the most on music for each country. 
Write a query that returns the country along with the top customer and how much they spent. 
For countries where the top amount spent is shared, provide all customers who spent this amount. */

/* Steps to Solve:  Similar to the above question. There are two parts in question- 
first find the most spent on music for each country and second filter the data for respective customers. */

/* Method 1: using CTE */

WITH Customer_with_country AS (
    SELECT cust.customer_id, cust.first_name, cust.last_name, 
	invoice.billing_country, SUM(invoice.total) AS total_spending,
    ROW_NUMBER() OVER(PARTITION BY invoice.billing_country 
    ORDER BY SUM(invoice.total) DESC) AS RowNo
    FROM invoice
    JOIN cust ON cust.customer_id = invoice.customer_id
    GROUP BY cust.customer_id, cust.first_name, cust.last_name, 
	invoice.billing_country
)
    SELECT * FROM Customer_with_country WHERE RowNo = 1
    ORDER BY billing_country ASC, total_spending DESC;




************************************************ Thank You *********************************************************************


