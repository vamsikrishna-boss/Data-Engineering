-----------------------------Select the All tables in Side Database--------------------------
Select * from [dbo].[employee]
Select * from [dbo].[Cust]
Select * from [dbo].[invoice]
Select * from [dbo].[Invoice_line]
Select * from [dbo].[track]
Select * from [dbo].[media_type]
Select * from [dbo].[Genre]
Select * from [dbo].[playlist]
Select * from [dbo].[track_pl]
Select * from [dbo].[artist]
Select * from [dbo].[album]
---------------------------How to Change the Column Names----------------------------------
Exec sp_rename 'employee.copy of employee_id','employee_id','column';
Exec sp_rename 'Cust.Copy of customer_id','customer_id','Column';
Exec sp_rename 'invoice.Copy of invoice_id','invoice_id','Column';
Exec sp_rename 'invoice_line.Copy of invoice_line_id','invoice_line_id','Column';
Exec sp_rename 'track.Copy of track_id','track_id','Column';
Exec sp_rename 'media_type.Copy of media_type_id','media_type_id','Column';
Exec sp_rename 'Genre.Copy of genre_id','Genre_id','Column';
Exec sp_rename 'Playlist.Copy of playlist_id','playlist_id','Column';
Exec sp_rename 'track_pl.Copy of playlist_id','pl_id','Column';
Exec sp_rename 'artist.Copy of artist_id','artist_id','Column';
Exec sp_rename 'album.Copy of album_id','album_id','Column';

---------------------------How to Add the Primary key in Existing tables---------------------
-
--Step:1. Modify the column nullability property to Not Null
ALTER TABLE employee Alter COLUMN employee_id VARCHAR(50) NOT NULL
ALTER TABLE Cust Alter COLUMN Customer_id VARCHAR(255) NOT NULL
ALTER TABLE invoice Alter COLUMN invoice_id VARCHAR(50) NOT NULL
ALTER TABLE invoice_line Alter COLUMN invoice_line_id VARCHAR(30) NOT NULL
ALTER TABLE track Alter COLUMN track_id VARCHAR(50) NOT NULL
ALTER TABLE media_type Alter COLUMN media_type_id VARCHAR(50) NOT NULL
ALTER TABLE Genre Alter COLUMN Genre_id VARCHAR(50) NOT NULL
ALTER TABLE playlist Alter COLUMN playlist_id VARCHAR(50) NOT NULL
ALTER TABLE track_pl Alter COLUMN pl_id VARCHAR(50) NOT NULL
ALTER TABLE artist Alter COLUMN artist_id VARCHAR(50) NOT NULL
ALTER TABLE album Alter COLUMN album_id VARCHAR(50) NOT NULL

--Step:2. Add primary key Constarint
Alter table employee Add Constraint pk_employee_id primary key(employee_id)
Alter table Cust Add Constraint pk_Customer_id primary key(Customer_id)
Alter table invoice Add Constraint pk_invoice_id primary key(invoice_id)
Alter table invoice_line Add Constraint pk_invoice_line_id primary key(invoice_line_id)
Alter table track Add Constraint pk_track_id primary key(track_id)
Alter table media_type Add Constraint pk_media_type_id primary key(media_type_id)
Alter table Genre Add Constraint pk_Genre_id primary key(Genre_id)
Alter table playlist Add Constraint pk_playlist_id primary key(playlist_id)
Alter table track_pl Add Constraint pk_pl_id primary key(pl_id)
Alter table artist Add Constraint pk_artist_id primary key(artist_id)
Alter table album Add Constraint pk_album_id primary key(album_id)

----------------renames all existing table columns -----------------------------------
--Employee:
Exec sp_rename 'employee.copy of employee_id','employee_id','column';
Exec sp_rename 'employee.copy of last_name','last_name','column';
Exec sp_rename 'employee.copy of first_name','first_name','column';
Exec sp_rename 'employee.copy of title','tittle','column';
Exec sp_rename 'employee.copy of reports_to','reports_to','column';
Exec sp_rename 'employee.copy of levels','levels','column';
Exec sp_rename 'employee.copy of birthdate','birthdate','column';
Exec sp_rename 'employee.copy of hire_date','hire_date','column';
Exec sp_rename 'employee.copy of address','address','column';
Exec sp_rename 'employee.copy of City','City','column';
Exec sp_rename 'employee.copy of State','State','column';
Exec sp_rename 'employee.copy of Country','Country','column';
Exec sp_rename 'employee.copy of postal_code','postal_code','column';
Exec sp_rename 'employee.copy of phone','phone','column';
Exec sp_rename 'employee.copy of fax','fax','column';
Exec sp_rename 'employee.copy of email','email','column';

--Cust:
Exec sp_rename 'Cust.Copy of customer_id','customer_id','Column';
Exec sp_rename 'Cust.Copy of first_name','first_name','Column';
Exec sp_rename 'Cust.Copy of last_name','last_name','Column';
Exec sp_rename 'Cust.Copy of Company','Company','Column';
Exec sp_rename 'Cust.Copy of address','address','Column';
Exec sp_rename 'Cust.Copy of City','City','Column';
Exec sp_rename 'Cust.Copy of State','State','Column';
Exec sp_rename 'Cust.Copy of Country','Country','Column';
Exec sp_rename 'Cust.Copy of postal_code','postal_code','Column';
Exec sp_rename 'Cust.Copy of phone','phone','Column';
Exec sp_rename 'Cust.Copy of fax','fax','Column';
Exec sp_rename 'Cust.Copy of support_rep_id','support_rep_id','Column';
Exec sp_rename 'Cust.Copy of email','email','Column';

--invoice: 
Exec sp_rename 'invoice.Copy of invoice_id','invoice_id','Column';
Exec sp_rename 'invoice.Copy of customer_id','customer_id','Column';
Exec sp_rename 'invoice.Copy of invoice_date','invoice_date','Column';
Exec sp_rename 'invoice.Copy of billing_address','billing_address','Column';
Exec sp_rename 'invoice.Copy of billing_city','billing_city','Column';
Exec sp_rename 'invoice.Copy of billing_state','billing_state','Column';
Exec sp_rename 'invoice.Copy of billing_country','billing_country','Column';
Exec sp_rename 'invoice.Copy of billing_postal_code','billing_postal_code','Column';
Exec sp_rename 'invoice.Copy of total','total','Column';

--Invoice_line:
Exec sp_rename 'invoice_line.Copy of invoice_line_id','invoice_line_id','Column';
Exec sp_rename 'invoice_line.Copy of invoice_id','invoice_id','Column';
Exec sp_rename 'invoice_line.Copy of track_id','track_id','Column';
Exec sp_rename 'invoice_line.Copy of unit_price','unit_price','Column';
Exec sp_rename 'invoice_line.Copy of quantity','quantity','Column';

--Track
Exec sp_rename 'track.Copy of track_id','track_id','Column';
Exec sp_rename 'track.Copy of name','name','Column';
Exec sp_rename 'track.Copy of album_id','album_id','Column';
Exec sp_rename 'track.Copy of media_type_id','media_type_id','Column';
Exec sp_rename 'track.Copy of genre_id','genre_id','Column';
Exec sp_rename 'track.Copy of composer','composer','Column';
Exec sp_rename 'track.Copy of milliseconds','milliseconds','Column';
Exec sp_rename 'track.Copy of bytes','bytes','Column';
Exec sp_rename 'track.Copy of unit_price','unit_price','Column';

--media type;
Exec sp_rename 'media_type.Copy of media_type_id','media_type_id','Column';
Exec sp_rename 'media_type.Copy of name','name','Column';

--Genre:
Exec sp_rename 'Genre.Copy of genre_id','Genre_id','Column';
Exec sp_rename 'Genre.Copy of name','name','Column';

--playlist:
Exec sp_rename 'Playlist.Copy of playlist_id','playlist_id','Column';
Exec sp_rename 'Playlist.Copy of name','name','Column';

--track_pl:
Exec sp_rename 'track_pl.Copy of playlist_id','pl_id','Column';
Exec sp_rename 'track_pl.Copy of name','name','Column';

--Artist:
Exec sp_rename 'artist.Copy of artist_id','artist_id','Column';
Exec sp_rename 'artist.Copy of name','name','Column';

--Album:
Exec sp_rename 'album.Copy of album_id','album_id','Column';
Exec sp_rename 'album.Copy of title','tittle','Column';
Exec sp_rename 'album.Copy of artist_id','artist_id','Column';

----------------------------------------------------------------------The End-------------------------------------------------------



