---------------------------Create A Database-----------------------------------

CREATE DATABASE W_Sales;

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'WL_Sales')
BEGIN
    CREATE DATABASE WL_Sales;
END;

---------------------  Create Table --------------------------------------------------------------

IF NOT EXISTS (Select * from INFORMATION_SCHEMA.TABLES Where Table_Name = 'Sales')
BEGIN
    Create table Sales(
	invoice_id VARCHAR(30) NOT NULL PRIMARY KEY,
    branch VARCHAR(5) NOT NULL,
    city VARCHAR(30) NOT NULL,
    customer_type VARCHAR(30) NOT NULL,
    gender VARCHAR(30) NOT NULL,
    product_line VARCHAR(100) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    tax_pct DECIMAL(6,4) NOT NULL,
    total DECIMAL(12, 4) NOT NULL,
    date DATETIME NOT NULL,
    time TIME NOT NULL,
    payment VARCHAR(15) NOT NULL,
    cogs DECIMAL(10,2) NOT NULL,
    gross_margin_pct DECIMAL(11,9),
    gross_income DECIMAL(12, 4),
    rating DECIMAL(2, 1)
);
END

create table nani (name varchar(50)) 

Select * from [dbo].[OLE DB Destination]
Select * from Sales
Select * from [dbo].[OLE]


--------------------------Rename of the colums------------------------------------------
Exec sp_rename 'OLE.Copy of invoice ID','invoice ID','column';
Exec sp_rename 'OLE.Copy of Branch','Branch','column';
Exec sp_rename 'OLE.Copy of City','City','column';
Exec sp_rename 'OLE.Copy of Customer type','Customer type','column';
Exec sp_rename 'OLE.Copy of Gender','Gender','column';
Exec sp_rename 'OLE.Copy of Product line','Product line','column';
Exec sp_rename 'OLE.Copy of Unit price','Unit price','column';
Exec sp_rename 'OLE.Copy of Quantity','Quantity','column';
Exec sp_rename 'OLE.Copy of Tax 5%','Tax 5%','column';
Exec sp_rename 'OLE.Copy of Total','Total','column';
Exec sp_rename 'OLE.Copy of Date','Date','column';
Exec sp_rename 'OLE.Copy of Time','Time','column';
Exec sp_rename 'OLE.Copy of Payment','Payment','column';
Exec sp_rename 'OLE.Copy of cogs','cogs','column';
Exec sp_rename 'OLE.Copy of gross margin percentage','gross margin_percentage','column';
Exec sp_rename 'OLE.Copy of gross income','gross income','column';
Exec sp_rename 'OLE.Copy of rating','rating','column';

----------------------------------------- Add time of the day columns -----------------------------------------------------------------

SELECT
    time,
    (CASE
        WHEN time BETWEEN '00:00:00' AND '12:00:00' THEN 'Morning'
        WHEN time > '12:00:00' AND time <= '16:00:00' THEN 'Afternoon'
        ELSE 'Evening'
    END) AS time_of_day
FROM OLE;

----------------------------------------- Add the column ---------------------------------------------------------------------------------
ALTER TABLE OLE ADD time_of_day VARCHAR(50) NULL;

----------------------------------------- Update Sales ------------------------------------------------------------------------------------

UPDATE OLE
SET time_of_day = (
    CASE
        WHEN time BETWEEN '00:00:00' AND '12:00:00' THEN 'Morning'
        WHEN time > '12:00:00' AND time <= '16:00:00' THEN 'Afternoon'
        ELSE 'Evening'
    END
);

-------------------------------------------------- Add day_name column  ----------------------------------------------------------------
SELECT date, DATENAME(WEEKDAY, date) AS day_name FROM OLE;
-------------------------------------------------- AdD column --------------------------------------------------------------------------
ALTER TABLE OLE ADD day_name VARCHAR(50)
-------------------------------------------------- Update the column -------------------------------------------------------------------
UPDATE OLE SET day_name = DATENAME(WEEKDAY, date);
-------------------------------------------------- Add month_name column ----------------------------------------------------------------
SELECT date,DATENAME(MONTH, date) AS month_name FROM sales;
-------------------------------------------------- Add Month name Column ----------------------------------------------------------------
ALTER TABLE OLE ADD month_name VARCHAR(10);
-------------------------------------------------- Update month name column ---------------------------------------------------------------
UPDATE OLE SET month_name = DATENAME(WEEKDAY,date);
-------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------- Generic -----------------------------------------------------------------------------------
----- How many unique cities does the data have?

      Select DISTINCT city from OLE

----- In which city is each branch?
      SELECT BRANCH,CITY
       FROM OLE;

-----How many unique product lines does the data have?

    SELECT 
	COUNT(DISTINCT [Product line]) AS UniqueProductLineCount
    FROM OLE;

-----What is the most common payment method?

     SELECT TOP 1 [Payment], COUNT(*) AS PaymentMethodCount
     FROM OLE
     GROUP BY [Payment]
     ORDER BY PaymentMethodCount DESC;

----What is the most selling product line?
SELECT TOP 1 [Product line], SUM(Quantity) AS TotalSales
   FROM OLE
   GROUP BY [Product line]
   ORDER BY TotalSales DESC;
   

----What is the total revenue by month?
 SELECT 
    FORMAT(date, 'yyyy-MM') AS MonthYear,
    SUM(total) AS TotalRevenue
FROM OLE
GROUP BY FORMAT(date, 'yyyy-MM')
ORDER BY MonthYear;

----What month had the largest COGS?
SELECT TOP 1
    FORMAT(date, 'yyyy-MM') AS MonthYear,
    SUM(cogs) AS TotalCOGS
FROM OLE
GROUP BY FORMAT(date, 'yyyy-MM')
ORDER BY TotalCOGS DESC;

----What product line had the largest revenue?
SELECT TOP 1 
    [Product line], 
    SUM(total) AS TotalRevenue
FROM OLE
GROUP BY [Product line]
ORDER BY SUM(total) DESC;
 

----What is the city with the largest revenue?
SELECT TOP 1 
    city, 
    SUM(total) AS TotalRevenue
FROM OLE
GROUP BY city
ORDER BY TotalRevenue DESC;

----What product line had the largest VAT?
SELECT TOP 1 
    [Product line], 
    SUM(Total * ([Tax 5%] / 100)) AS TotalVAT
FROM OLE
GROUP BY [Product line]
ORDER BY TotalVAT DESC;

----Fetch each product line and add a column to those product line showing "Good", "Bad". Good if its greater than average sales
WITH SalesData AS (
    SELECT 
        [Product line],
        SUM(Quantity) AS TotalSales
    FROM OLE
    GROUP BY [Product line]
),
AverageSales AS (
    SELECT 
        AVG(TotalSales) AS AverageTotalSales
    FROM SalesData
)

SELECT 
    sd.[Product line],
    sd.TotalSales,
    CASE 
        WHEN sd.TotalSales > asd.AverageTotalSales THEN 'Good'
        ELSE 'Bad'
    END AS SalesCategory
FROM SalesData sd
CROSS JOIN AverageSales asd;

----Which branch sold more products than average product sold?
WITH BranchSales AS (
    SELECT 
        Branch, 
        SUM(Quantity) AS TotalSales
    FROM OLE
    GROUP BY Branch
),
AverageSales AS (
    SELECT 
        AVG(TotalSales) AS AverageTotalSales
    FROM BranchSales
)

SELECT 
    bs.Branch, 
    bs.TotalSales
FROM BranchSales bs
JOIN AverageSales asd ON bs.TotalSales > asd.AverageTotalSales;

----What is the most common product line by gender?
WITH RankedProducts AS (
    SELECT 
        Gender, 
        [Product line], 
        COUNT(*) AS ProductLineCount,
        ROW_NUMBER() OVER (PARTITION BY Gender ORDER BY COUNT(*) DESC) AS Rank
    FROM OLE
    GROUP BY Gender, [Product line]
)

SELECT 
    Gender, 
    [Product line], 
    ProductLineCount
FROM RankedProducts
WHERE Rank = 1;


----What is the average rating of each product line?
SELECT 
    [Product line], 
    AVG(rating) AS AverageRating
FROM OLE
GROUP BY [Product line]
ORDER BY [Product line];

----Number of sales made in each time of the day per weekday
SELECT 
    DATENAME(WEEKDAY, Date) AS Weekday,
    CAST(Time AS TIME) AS TimeOfDay,
    COUNT(*) AS NumberOfSales
FROM OLE
GROUP BY 
    DATENAME(WEEKDAY, Date),
    CAST(Time AS TIME)
ORDER BY 
    DATENAME(WEEKDAY, Date),
    TimeOfDay;

----Which of the customer types brings the most revenue?
SELECT 
    [Customer type], 
    SUM(Total) AS TotalRevenue
FROM OLE
GROUP BY [Customer type]
ORDER BY TotalRevenue DESC;


----Which city has the largest tax percent/ VAT (Value Added Tax)?

SELECT TOP 1 
    City, 
    SUM(Total * ([Tax 5%] / 100)) AS TotalVAT
FROM OLE
GROUP BY City
ORDER BY TotalVAT DESC;



----Which customer type pays the most in VAT?
SELECT TOP 1 
    [Customer type], 
    SUM(Total * ([Tax 5%] / 100)) AS TotalVAT
FROM OLE
GROUP BY [Customer type]
ORDER BY TotalVAT DESC;

----How many unique customer types does the data have?
SELECT COUNT(DISTINCT [Customer type]) AS UniqueCustomerTypeCount
FROM OLE


----How many unique payment methods does the data have?
SELECT COUNT(DISTINCT Payment) AS UniquePaymentMethodCount
FROM OLE;

----What is the most common customer type?
SELECT TOP 1 
    [Customer type], 
    COUNT(*) AS CustomerTypeCount
FROM OLE
GROUP BY [Customer type]
ORDER BY CustomerTypeCount DESC;


----Which customer type buys the most?
SELECT TOP 1 
    [Customer type], 
    SUM(Quantity) AS TotalQuantity
FROM OLE
GROUP BY [Customer type]
ORDER BY TotalQuantity DESC;


----What is the gender of most of the customers?
SELECT TOP 1 
    Gender, 
    COUNT(*) AS CustomerCount
FROM OLE
GROUP BY Gender
ORDER BY CustomerCount DESC;

----What is the gender distribution per branch?
SELECT 
    Branch, 
    Gender, 
    COUNT(*) AS GenderCount
FROM OLE
GROUP BY Branch, Gender
ORDER BY Branch, Gender;


----Which time of the day do customers give most ratings?
SELECT 
    CAST(Time AS TIME) AS TimeOfDay, 
    COUNT(rating) AS RatingCount
FROM OLE
WHERE rating IS NOT NULL
GROUP BY CAST(Time AS TIME)
ORDER BY RatingCount DESC;

----Which time of the day do customers give most ratings per branch?
SELECT 
    Branch, 
    CAST(Time AS TIME) AS TimeOfDay, 
    COUNT(rating) AS RatingCount
FROM OLE
WHERE rating IS NOT NULL
GROUP BY Branch, CAST(Time AS TIME)
ORDER BY Branch, RatingCount DESC;

----Which day fo the week has the best avg ratings?
SELECT 
    DATENAME(WEEKDAY, Date) AS DayOfWeek, 
    AVG(rating) AS AverageRating
FROM OLE
WHERE rating IS NOT NULL
GROUP BY DATENAME(WEEKDAY, Date)
ORDER BY AverageRating DESC;

----Which day of the week has the best average ratings per branch?
SELECT 
    Branch, 
    DATENAME(WEEKDAY, Date) AS DayOfWeek, 
    AVG(rating) AS AverageRating
FROM OLE
WHERE rating IS NOT NULL
GROUP BY Branch, DATENAME(WEEKDAY, Date)
ORDER BY Branch, AverageRating DESC;









      
	





